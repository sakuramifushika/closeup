susato-model 1.4+ 适配游戏5.0以上
一个由susato作画、miyako2428打包的美化模组，包含小人所有部件和特写。

credits:
susato(寿里), m for artwork
miyako4828 for modloading
白玉 for backgrounds/foregrounds
tomato(头摩头), 精神安定剂, Eudemonism00(前略中略后略), KzG, Wednesday, 殘響 for testing

decorations_zh
credits:
J-Side for code
Sewer for modloadering 
Hikari, Saiko, AliceMMD for backgrounds/foregrounds
Mary for translation

特别感谢以下人员对本MOD的帮助（排名不分先后）：
JeremieLyoko
sewer
J-Side
here2fap
Number_Sir
CK Rainbow
Lyra
Frostberg