新增服装、发型、转化贴图 ver 0.2.4
适配susato人模与susato特写。
仅支持ModLoader加载，需要susato-model作为前置。

Added clothing, hairstyle and transformation maps ver 0.2.4 to adapt susato mannequins and susato close-ups. 
Only support ModLoader loading, need susato-model as frontend. 

credit: 
寿里，水色，白玉，葬莜，好，miyako4828 for artwork
miyako4828 for modloading

禁止无授权转载。
Unauthorised reproduction is prohibited.
무단 복제는 금지되어 있습니다.

